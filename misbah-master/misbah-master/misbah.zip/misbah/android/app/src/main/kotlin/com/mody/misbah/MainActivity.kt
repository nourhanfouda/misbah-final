package com.mody.misbah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
